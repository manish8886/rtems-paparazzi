/*
 * device_names.h
 *
 *  Created on: Jun 8, 2013
 *      Author: manish
 */

#ifndef DEVICE_NAMES_H_
#define DEVICE_NAMES_H_

#define gps_device1      "/dev/gps1"
#define GPS_DEVICE_NO     1

#endif /* DEVICE_NAMES_H_ */
