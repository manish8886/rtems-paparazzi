char ivy_buf[256];
char *ivy_p = ivy_buf;
char *plen =&ivy_buf[1];
