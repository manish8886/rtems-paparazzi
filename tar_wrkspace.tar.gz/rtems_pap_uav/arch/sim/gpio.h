#ifndef GPIO_H
#define GPIO_H

extern bool_t gpio1_status;

#endif /* GPIO_H */

