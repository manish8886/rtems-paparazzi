#ifndef LED_HW_H
#define LED_HW_H

#include <stdio.h>



#define LED_INIT(i) { }
#define LED_ON(i) { }
#define LED_OFF(i) {}
#define LED_TOGGLE(i) {  }

#define LED_PERIODIC() {}

#endif /* LED_HW_H */
