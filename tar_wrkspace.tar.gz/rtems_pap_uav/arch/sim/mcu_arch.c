

void mcu_arch_init(void) {}
