#include "subsystems/settings.h"


int32_t persistent_write(uint32_t ptr, uint32_t size) {
  ptr=ptr;
  size=size;
  return 0;
}

int32_t persistent_read(uint32_t ptr, uint32_t size) {
  ptr=ptr;
  size=size;
  return 0;
}
